<?php
include 'header.php';
include 'navbar.php';
include 'sidebar_menu.php';
include 'main_content.php';
include 'footer.php';
?>


<!-- Preloader -->
<!-- <div class="preloader flex-column justify-content-center align-items-center">
<img class="animation__shake" src="assets/dist/img/AdminLTELogo.png" alt="AdminLTELogo" height="60" width="60">
</div> -->







